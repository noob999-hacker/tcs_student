Contents:
"TM-46 Soviet Anti-Tank Mine" 3D Printable Model in .blend, .stl, .obj, .fbx, and .glb.

Can be used for:
Game development
Rendering and animation
3D printing

Notes:
No textures included, geometry only model
if being used for printing, .stl is recomended in most cases.
other file formats have been included for other uses than printing 

License:
Personal and commercial use is allowed
credit is not needed, but is appreciated
DO NOT re-sell or distrobute files as is, only as part of a project

contact:
Itch profile - https://butteredpeanuts.itch.io/ 

